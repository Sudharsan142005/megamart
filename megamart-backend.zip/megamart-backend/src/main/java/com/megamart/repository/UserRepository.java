package com.megamart.repository;

import com.megamart.entity.ERole;
import com.megamart.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
    List<User> findByRolesName(ERole roleName);
    List<User> findByRolesNameAndApprovalStatus(ERole roleName, String approvalStatus);
    long countByRolesName(ERole roleName);
    long countByRolesNameAndApprovalStatus(ERole roleName, String approvalStatus);
}
